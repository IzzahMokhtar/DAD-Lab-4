package serverApp;

public class ServerTranslationApp {

}

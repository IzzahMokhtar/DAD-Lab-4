package clientApp;

public class ClientTranslationApp {

}
